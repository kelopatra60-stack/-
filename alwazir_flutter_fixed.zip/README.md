# الوزير — Alwazir Chess Flutter

مشروع Flutter/Dart للعبة «الوزير» مبني على نسخة V41 الأصلية، مع الحفاظ على هوية الواجهة واتجاه RTL واللوحة 2D والاقتصاد المحلي.

## ما تم إصلاحه في هذه النسخة

- محرك شطرنج مستقل مع FEN والحركات الشرعية والتبييت والأخذ بالتجاوز والترقية والكش والتعادل.
- Stockfish 1.8.1 عبر FFI، مع إعادة تهيئة آمنة بعد `dispose` ومنع تعدد المحركات النشطة.
- حفظ ملكية القطع والثيمات والإطارات والمؤثرات، ومنع اختيار المحتوى المدفوع قبل شرائه.
- احتساب الفوز/الخسارة/التعادل وكش مات والقطع المأخوذة وXP والمستوى.
- حفظ التقدم محليًا عبر SharedPreferences.
- أونلاين Firebase Realtime Database: غرف خاصة، مزامنة FEN والنقلات، حضور، ومطابقة عشوائية ذرّية عبر Firebase Transaction.
- GitHub Actions يشغل التحليل والاختبارات ويبني APK Release باستخدام قناة Flutter stable.

## ملاحظة مهمة حول Firebase

لا يمكن وضع بيانات مشروع Firebase حقيقية داخل هذا المستودع دون أن يزوّد صاحب المشروع بيانات مشروعه. لذلك لا توجد أسرار أو مفاتيح وهمية هنا. بعد ربط مشروع Firebase الحقيقي بتطبيق Android، يعمل الأونلاين فعليًا.

## التشغيل

```bash
flutter pub get
flutter analyze
flutter test
flutter create . --platforms=android --org com.alwazir --project-name alwazir_chess
flutter run
```

بعد ربط Firebase، أضف ملفات إعداد Firebase الخاصة بمشروعك ثم شغّل:

```bash
flutterfire configure
flutter pub get
flutter run
```

## الاختبارات

`test/chess_engine_test.dart` يحتوي اختبارات لقواعد شطرنج أساسية. يجب تشغيل `flutter test` على جهاز/بيئة Flutter فعلية قبل إصدار APK.

## البناء الآلي

`.github/workflows/build.yml` يستخدم Flutter stable، ثم:

```text
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```

ويرفع APK الناتج كـ GitHub Actions artifact.

## الاعتماديات الرئيسية

- `stockfish: ^1.8.1`
- `firebase_core`
- `firebase_database`
- `shared_preferences`
- `flutter_svg`
- `google_fonts`

إصدار Stockfish 1.8.1 هو إصدار Stockfish 18 في حزمة Flutter الحالية. urlتوثيق Stockfish 1.8.1https://pub.dev/packages/stockfish/versions/1.8.1
