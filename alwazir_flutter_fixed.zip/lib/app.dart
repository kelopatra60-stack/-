import 'dart:async';
import 'dart:math';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'chess_engine.dart';
import 'theme.dart';
import 'services/online_service.dart';
import 'services/stockfish_service.dart';
import 'services/storage_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  try { await Firebase.initializeApp(); } catch (_) {}
  runApp(const AlwazirApp());
}

class AlwazirApp extends StatelessWidget {
  const AlwazirApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(debugShowCheckedModeBanner:false, theme:AppTheme.data, home:const Shell());
}

class Shell extends StatefulWidget { const Shell({super.key}); @override State<Shell> createState()=>_ShellState(); }
class _ShellState extends State<Shell> {
  final store=StorageService();
  final sf=StockfishService();
  final random=Random();
  String screen='menu', mode='local', boardTheme='classic', pieceSkin='classic', playerName='لاعب الوزير';
  int aiLevel=2, selectedMinutes=5, gold=5000, gems=500, xp=0, level=1;
  int wins=0, losses=0, draws=0, games=0, captures=0, checkmates=0;
  int whiteSeconds=300, blackSeconds=300;
  bool flipped=false, paused=false, aiThinking=false, sound=true, autoSave=true, smooth=true;
  ChessState state=ChessState.initial();
  final history=<String>[];
  final moveHistory=<String>[];
  Square? selected;
  Timer? timer;
  OnlineService? online;
  StreamSubscription? onlineSub;
  String? roomId;
  int onlineSeq=0;
  bool onlineHost=false;

  final themes=<Map<String,String>>[
    {'id':'classic','name':'كلاسيكي','l':'#E9DFC9','d':'#5B4636'}, {'id':'emerald','name':'زمردي','l':'#D8E3C8','d':'#416452'},
    {'id':'ruby','name':'ياقوتي','l':'#EAD2CE','d':'#71444A'}, {'id':'night','name':'ليل أزرق','l':'#CBD5DF','d':'#3D536B'},
    {'id':'violet','name':'بنفسجي','l':'#E2D7EE','d':'#5B4472'}, {'id':'rosegold','name':'وردي ذهبي','l':'#F2DDD6','d':'#8A5A54'},
    {'id':'obsidian','name':'أوبسيديان','l':'#3A3A3F','d':'#141417'}, {'id':'ocean','name':'محيطي','l':'#CFE6EA','d':'#2C5D6B'},
    {'id':'forest','name':'غابة','l':'#DBE4C6','d':'#3F5732'}, {'id':'crimson','name':'قرمزي','l':'#ECD2CA','d':'#6E2A2A'},
    {'id':'slate','name':'أردوازي','l':'#D9DEE3','d':'#4A5560'}, {'id':'copper','name':'نحاسي','l':'#ECDCC6','d':'#8A5A2E'},
  ];
  final pieceSkins=['classic','gold','onyx','emerald','ice','violet'];
  final frames=[['gold','إطار ذهبي','مميز',700],['obsidian','إطار أوبسيديان','نادر',1100],['emerald','إطار زمردي','ملحمي',1500]];
  final effects=[['gold','وهج ذهبي','مميز',500],['ice','وهج جليدي','نادر',900],['violet','وهج بنفسجي','ملحمي',1300]];
  String activeFrame='gold', activeEffect='gold';
  final ownedPieces=<String>{'classic'};
  final ownedThemes=<String>{'classic'};
  final ownedFrames=<String>{'gold'};
  final ownedEffects=<String>{'gold'};
  bool matchSearching=false;
  String? matchPlayerId;
  StreamSubscription? queueSub;

  @override void initState(){super.initState(); _load(); timer=Timer.periodic(const Duration(seconds:1),(_)=>_tick());}
  @override void dispose(){timer?.cancel();onlineSub?.cancel();queueSub?.cancel();sf.dispose();super.dispose();}
  void _tick(){if(!mounted||screen!='game'||paused||ChessEngine.status(state,positionHistory:history).over)return;setState((){if(state.turn==ColorSide.white){if(whiteSeconds>0)whiteSeconds--;}else{if(blackSeconds>0)blackSeconds--;}});if(whiteSeconds==0||blackSeconds==0)_finishByTime();}
  Future<void> _load() async{
    playerName=await store.get('profile_name')??playerName; boardTheme=await store.get('v24_theme')??'classic'; pieceSkin=await store.get('v24_active_piece')??'classic'; activeFrame=await store.get('v24_frame')??'gold'; activeEffect=await store.get('v24_effect')??'gold';
    gold=await store.intValue('alwazir_gold',5000);gems=await store.intValue('v8_gems',500);xp=await store.intValue('xp',0);level=await store.intValue('level',1);
    ownedPieces.addAll(await store.stringList('owned_pieces')); ownedThemes.addAll(await store.stringList('owned_themes')); ownedFrames.addAll(await store.stringList('owned_frames')); ownedEffects.addAll(await store.stringList('owned_effects'));
    wins=await store.intValue('wins',0);losses=await store.intValue('losses',0);draws=await store.intValue('draws',0);games=await store.intValue('games',0);captures=await store.intValue('captures',0);checkmates=await store.intValue('checkmates',0);
    if(mounted)setState((){});
  }
  Future<void> _save() async{await store.set('profile_name',playerName);await store.set('v24_theme',boardTheme);await store.set('v24_active_piece',pieceSkin);await store.set('v24_frame',activeFrame);await store.set('v24_effect',activeEffect);await store.setInt('alwazir_gold',gold);await store.setInt('v8_gems',gems);await store.setInt('xp',xp);await store.setInt('level',level);await store.setInt('wins',wins);await store.setInt('losses',losses);await store.setInt('draws',draws);await store.setInt('games',games);await store.setInt('captures',captures);await store.setInt('checkmates',checkmates);await store.setStringList('owned_pieces',ownedPieces.toList());await store.setStringList('owned_themes',ownedThemes.toList());await store.setStringList('owned_frames',ownedFrames.toList());await store.setStringList('owned_effects',ownedEffects.toList());}
  void nav(String s){if(mounted)setState(()=>screen=s);}

  @override Widget build(BuildContext context){
    Widget body=switch(screen){'menu'=>_menu(),'setupLocal'=>_setup(false),'setupAI'=>_setup(true),'game'=>_game(),'settings'=>_settings(),'account'=>_account(),'store'=>_store(),'achievements'=>_achievements(),'tasks'=>_tasks(),'stats'=>_stats(),'map'=>_map(),'online'=>_online(),_=>_menu()};
    return Directionality(textDirection:TextDirection.rtl,child:SafeArea(child:AnimatedSwitcher(duration:const Duration(milliseconds:250),child:body)));
  }

  Widget _page(String title,Widget child,{bool back=true})=>SingleChildScrollView(padding:const EdgeInsets.fromLTRB(14,8,14,30),child:Column(children:[if(back)Align(alignment:Alignment.centerRight,child:IconButton(onPressed:()=>nav('menu'),icon:const Icon(Icons.arrow_back,color:AppTheme.goldBright))),Row(mainAxisAlignment:MainAxisAlignment.center,children:[Container(width:38,height:38,decoration:Ui.goldButton(radius:10),child:const Icon(Icons.workspace_premium,color:AppTheme.onyx2)),const SizedBox(width:10),Text(title,style:AppTheme.amiri(22))]),const SizedBox(height:16),child]));
  Widget _card(String title,String desc,IconData icon,VoidCallback tap)=>InkWell(onTap:tap,borderRadius:BorderRadius.circular(16),child:Container(margin:const EdgeInsets.only(bottom:12),padding:const EdgeInsets.all(16),decoration:Ui.panel(),child:Row(children:[Container(width:50,height:50,decoration:BoxDecoration(color:Colors.white.withOpacity(.05),borderRadius:BorderRadius.circular(12)),child:Icon(icon,color:AppTheme.goldBright,size:25)),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:15.5,fontWeight:FontWeight.w800)),const SizedBox(height:3),Text(desc,style:const TextStyle(fontSize:12,color:AppTheme.muted))])),const Icon(Icons.chevron_left,color:AppTheme.goldBright)])));
  Widget _menu()=>_page('الوزير',Column(children:[Text('اختر طريقة اللعب',style:const TextStyle(color:AppTheme.muted,fontWeight:FontWeight.w800,letterSpacing:1.4)),const SizedBox(height:10),_card('ضد الذكاء الاصطناعي','تحديات بأربع درجات صعوبة',Icons.smart_toy,(){mode='ai';nav('setupAI');}),_card('لاعبان محلي','مباراة على نفس الجهاز',Icons.people_alt,(){mode='local';nav('setupLocal');}),_card('لعب أونلاين','غرفة خاصة أو مطابقة',Icons.public,()=>nav('online')),GridView.count(crossAxisCount:3,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisSpacing:8,mainAxisSpacing:8,children:[_mini('⚙','الإعدادات','settings'),_mini('♙','الحساب','account'),_mini('🛒','المتجر','store'),_mini('🏆','الإنجازات','achievements'),_mini('✓','المهام','tasks'),_mini('📊','الإحصائيات','stats'),_mini('🗺','المراحل','map')])]))
  Widget _mini(String icon,String label,String target)=>InkWell(onTap:()=>nav(target),borderRadius:BorderRadius.circular(14),child:Container(decoration:Ui.panel(radius:14),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(icon,style:const TextStyle(fontSize:22)),const SizedBox(height:5),Text(label,style:const TextStyle(fontSize:10,fontWeight:FontWeight.w800,color:AppTheme.muted))])));

  Widget _setup(bool ai){
    return _page(ai?'إعداد اللعب ضد الكمبيوتر':'إعداد اللعب المحلي',Column(children:[
      Container(decoration:Ui.panel(),padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('الوقت',style:TextStyle(color:AppTheme.goldBright,fontSize:11,fontWeight:FontWeight.w900)),
        const SizedBox(height:8),
        Wrap(spacing:8,runSpacing:8,children:[for(final t in [1,3,5,10,15,30])ChoiceChip(label:Text('$t دقائق'),selected:t==selectedMinutes,onSelected:(_)=>setState(()=>selectedMinutes=t))]),
        if(ai) ...[
          const SizedBox(height:14),
          const Text('الصعوبة',style:TextStyle(color:AppTheme.goldBright,fontSize:11,fontWeight:FontWeight.w900)),
          for(var i=1;i<=4;i++) RadioListTile<int>(dense:true,value:i,groupValue:aiLevel,onChanged:(v)=>setState(()=>aiLevel=v!),title:Text(['سهل','متوسط','صعب','خبير'][i-1]),secondary:Text('★'*i,style:const TextStyle(color:AppTheme.goldBright))),
        ],
      ])),
      const SizedBox(height:14),
      _button('ابدأ المباراة',_startGame),
    ]));
  }

  Widget _button(String label,VoidCallback tap)=>InkWell(onTap:tap,borderRadius:BorderRadius.circular(12),child:Container(width:double.infinity,padding:const EdgeInsets.symmetric(vertical:13),decoration:Ui.goldButton(),alignment:Alignment.center,child:Text(label,style:const TextStyle(color:AppTheme.onyx2,fontWeight:FontWeight.w900))));
  void _startGame(){state=ChessState.initial();history..clear()..add(_positionKey(state));moveHistory.clear();selected=null;whiteSeconds=blackSeconds=selectedMinutes*60;flipped=false;paused=false;aiThinking=false;onlineSeq=0;nav('game');}
  String _positionKey(ChessState s)=>s.toFen().split(' ').sublist(0,4).join(' ');

  Widget _game(){
    final status=ChessEngine.status(state,positionHistory:history);
    final indices=List<int>.generate(64,(i)=>flipped?63-i:i);
    return Column(children:[
      Padding(padding:const EdgeInsets.fromLTRB(8,6,8,4),child:Row(children:[
        IconButton(onPressed:()=>nav('menu'),icon:const Icon(Icons.arrow_back,color:AppTheme.goldBright)),
        Expanded(child:Text(mode=='ai'?'ضد الكمبيوتر':mode=='online'?'أونلاين':'لاعبان محلي',textAlign:TextAlign.center,style:AppTheme.amiri(21))),
        IconButton(onPressed:()=>setState(()=>paused=!paused),icon:Icon(paused?Icons.play_arrow:Icons.pause_circle_outline,color:AppTheme.goldBright)),
      ])),
      Row(children:[_clock('الأبيض',state.turn==ColorSide.white,whiteSeconds),_clock('الأسود',state.turn==ColorSide.black,blackSeconds)]),
      const SizedBox(height:4),
      Text(aiThinking?'الكمبيوتر يفكر…':_statusText(status),style:const TextStyle(color:AppTheme.goldBright,fontWeight:FontWeight.w800)),
      const SizedBox(height:8),
      Padding(padding:const EdgeInsets.all(8),child:AspectRatio(aspectRatio:1,child:Container(
        padding:const EdgeInsets.all(6),
        decoration:BoxDecoration(borderRadius:BorderRadius.circular(16),gradient:const LinearGradient(colors:[Color(0xFF2A2117),AppTheme.onyx2])),
        child:GridView.builder(
          physics:const NeverScrollableScrollPhysics(),
          itemCount:64,
          gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:8),
          itemBuilder:(context,i){
            final logical=indices[i],r=logical~/8,c=logical%8,p=state.board[r][c];
            final light=(r+c)%2==0,isSelected=selected==Square(r,c);
            final legalHint=selected!=null&&ChessEngine.legal(state,selected!.r,selected!.c).any((m)=>m.to.r==r&&m.to.c==c);
            return GestureDetector(onTap:()=>_tap(r,c),child:Container(
              decoration:BoxDecoration(color:light?_boardLight():_boardDark(),border:isSelected?Border.all(color:AppTheme.goldBright,width:3):null),
              child:Stack(alignment:Alignment.center,children:[
                if(legalHint&&p==null) Container(width:18,height:18,decoration:BoxDecoration(shape:BoxShape.circle,color:Colors.black.withOpacity(.30))),
                if(legalHint&&p!=null) Container(width:38,height:38,decoration:BoxDecoration(shape:BoxShape.circle,border:Border.all(color:AppTheme.goldBright,width:2))),
                if(p!=null) _piece(p),
                if(r==7) Positioned(left:3,bottom:2,child:Text(String.fromCharCode(97+c),style:const TextStyle(fontSize:8,fontWeight:FontWeight.w900,color:Colors.black54))),
                if(c==0) Positioned(right:3,top:2,child:Text('${8-r}',style:const TextStyle(fontSize:8,fontWeight:FontWeight.w900,color:Colors.black54))),
              ]),
            ));
          },
        ),
      ))),
      const SizedBox(height:4),
      Wrap(alignment:WrapAlignment.center,spacing:6,children:[
        _tool(Icons.undo,'تراجع',history.length>1?_undo:null),
        _tool(Icons.swap_vert,'قلب',()=>setState(()=>flipped=!flipped)),
        _tool(paused?Icons.play_arrow:Icons.pause,'إيقاف',()=>setState(()=>paused=!paused)),
        _tool(Icons.flag,'استسلام',_resign),
      ]),
      if(moveHistory.isNotEmpty) Container(margin:const EdgeInsets.fromLTRB(10,8,10,0),padding:const EdgeInsets.all(10),decoration:Ui.panel(radius:12),child:Text(moveHistory.join('   '),style:const TextStyle(fontSize:11,color:AppTheme.muted))),
      if(status.over) _result(status),
    ]);
  }

  Widget _result(GameStatus s){final title=s.status=='checkmate'?(s.winner==ColorSide.white?'فوز الأبيض':'فوز الأسود'):s.status=='stalemate'?'تعادل — جمود':s.status=='fifty_move'?'تعادل — قاعدة 50 نقلة':s.status=='threefold'?'تعادل — تكرار الوضعية':'تعادل — مادة غير كافية';return Container(margin:const EdgeInsets.all(12),padding:const EdgeInsets.all(16),decoration:Ui.panel(radius:18),child:Column(children:[Text('♛',style:TextStyle(fontSize:34,color:AppTheme.goldBright)),Text(title,style:AppTheme.amiri(21,color:AppTheme.goldBright)),const SizedBox(height:10),Row(children:[Expanded(child:_button('مباراة جديدة',_startGame)),const SizedBox(width:8),Expanded(child:OutlinedButton(onPressed:()=>nav('menu'),child:const Text('القائمة')))])]));}
  Widget _clock(String who,bool active,int seconds)=>Expanded(child:Container(margin:const EdgeInsets.all(5),padding:const EdgeInsets.symmetric(horizontal:12,vertical:9),decoration:BoxDecoration(color:(active?AppTheme.gold:AppTheme.onyx2).withOpacity(active?.20:.15),border:Border.all(color:active?AppTheme.gold:Colors.white.withOpacity(.06)),borderRadius:BorderRadius.circular(14)),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(who),Text('${(seconds~/60).toString().padLeft(2,'0')}:${(seconds%60).toString().padLeft(2,'0')}',style:AppTheme.amiri(20,color:seconds<30?AppTheme.danger:AppTheme.cream))])));
  Widget _tool(IconData icon,String label,VoidCallback? tap)=>SizedBox(width:82,child:ElevatedButton(onPressed:tap,style:ElevatedButton.styleFrom(backgroundColor:Colors.white.withOpacity(.03),foregroundColor:AppTheme.cream,padding:const EdgeInsets.symmetric(vertical:8),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(12),side:BorderSide(color:AppTheme.gold.withOpacity(.3)))),child:Column(children:[Icon(icon,size:16,color:AppTheme.goldBright),Text(label,style:const TextStyle(fontSize:9))])));
  void _tap(int r,int c){
    if(paused||aiThinking||ChessEngine.status(state,positionHistory:history).over)return;
    if(flipped){r=7-r;c=7-c;}
    if(mode=='ai'&&state.turn==ColorSide.black)return;
    if(mode=='online' && ((onlineHost && state.turn!=ColorSide.white) || (!onlineHost && state.turn!=ColorSide.black)))return;
    final p=state.board[r][c];
    if(selected==null){if(p!=null&&pieceColor(p)==(state.turn==ColorSide.white?'w':'b'))setState(()=>selected=Square(r,c));return;}
    final moves=ChessEngine.legal(state,selected!.r,selected!.c);final targets=moves.where((m)=>m.to.r==r&&m.to.c==c).toList();
    if(targets.isEmpty){if(p!=null&&pieceColor(p)==(state.turn==ColorSide.white?'w':'b'))setState(()=>selected=Square(r,c));else setState(()=>selected=null);return;}
    if(targets.length>1){_choosePromotion(targets);return;}
    _commitMove(targets.first);
  }
  void _choosePromotion(List<Move> moves){showModalBottomSheet(context:context,backgroundColor:AppTheme.onyx2,shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(20))),builder:(c)=>SafeArea(child:Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly,children:[for(final m in moves)Padding(padding:const EdgeInsets.all(14),child:IconButton(onPressed:(){Navigator.pop(c);_commitMove(m);},icon:Text(_promotionGlyph(m.promotion!),style:const TextStyle(fontSize:38,color:AppTheme.goldBright))))])));}
  String _promotionGlyph(PieceType p)=>switch(p){PieceType.queen=>'♛',PieceType.rook=>'♜',PieceType.bishop=>'♝',PieceType.knight=>'♞',_=>'♟'};
  void _commitMove(Move m,{bool remote=false}){
    final captured=state.board[m.to.r][m.to.c]!=null||m.enPassant;
    if(captured) captures++;
    state=ChessEngine.apply(state,m);
    history.add(_positionKey(state)); moveHistory.add(m.uci); selected=null;
    if(autoSave) _save();
    if(mode=='online'&&!remote){onlineSeq++;online?.writeMove(onlineSeq,m.uci,state.toFen());}
    if(mounted)setState((){});
    final result=ChessEngine.status(state,positionHistory:history);
    if(result.over) _finishGame(result);
    else if(mode=='ai'&&state.turn==ColorSide.black) _aiMove();
  }

  void _finishGame(GameStatus result){
    if(paused && result.over) return;
    paused=true; games++;
    if(result.status=='checkmate'){ checkmates++; if(result.winner==ColorSide.white) wins++; else losses++; }
    else draws++;
    xp+=result.status=='checkmate'?25:15;
    while(xp>=level*100){xp-=level*100;level++;}
    _save();
    if(mounted)setState((){});
  }

  Future<void> _aiMove() async{aiThinking=true;if(mounted)setState((){});final legal=ChessEngine.allLegal(state,ColorSide.black);if(legal.isEmpty){aiThinking=false;if(mounted)setState((){});return;}try{final uci=await sf.bestMove(state.toFen(),skill:[1,6,12,20][aiLevel-1],movetime:[250,500,900,1500][aiLevel-1]);final m=legal.firstWhere((x)=>x.uci==uci,orElse:()=>legal.first);_commitMove(m);}catch(_){_commitMove(legal.first);}aiThinking=false;if(mounted)setState((){});}
  void _undo(){if(history.length<=1)return;setState((){history.removeLast();if(moveHistory.isNotEmpty)moveHistory.removeLast();state=ChessState.fromFen(history.last);selected=null;});if(mode=='ai'&&history.length>1&&state.turn==ColorSide.black){setState((){history.removeLast();if(moveHistory.isNotEmpty)moveHistory.removeLast();state=ChessState.fromFen(history.last);});}}
  void _resign(){if(mode=='ai'){losses++;games++;}else if(mode=='local'){draws++;games++;}else{losses++;games++;} _save();nav('menu');}
  void _finishByTime(){if(paused)return;if(whiteSeconds==0||blackSeconds==0){paused=true;games++;if(mode=='ai'){if(whiteSeconds==0)losses++;else wins++;}else draws++;xp+=10;while(xp>=level*100){xp-=level*100;level++;}_save();if(mounted)setState((){});}}
  String _statusText(GameStatus s)=>switch(s.status){'check'=>'كش','checkmate'=>'كش مات','stalemate'=>'تعادل — جمود','fifty_move'=>'تعادل — 50 نقلة','threefold'=>'تعادل — تكرار','insufficient'=>'تعادل — مادة غير كافية',_=>'دور ${state.turn==ColorSide.white?'الأبيض':'الأسود'}'};
  Widget _piece(String p){final white=p==p.toUpperCase();final name=p.toLowerCase();final asset='assets/pieces/${white?'w':'b'}_$name.svg';return ColorFiltered(colorFilter:ColorFilter.mode(_pieceTint(),BlendMode.modulate),child:SvgPicture.asset(asset,width:50,height:50,fit:BoxFit.contain));}
  Color _pieceTint()=>_pieceTintFor(pieceSkin);
  Color _boardLight()=>_hex(themes.firstWhere((t)=>t['id']==boardTheme)['l']!);
  Color _boardDark()=>_hex(themes.firstWhere((t)=>t['id']==boardTheme)['d']!);
  Color _hex(String s){var h=s.replaceFirst('#','');if(h.length==6)h='FF$h';return Color(int.parse(h,radix:16));}

  Widget _settings()=>_page('الإعدادات',Container(decoration:Ui.panel(),padding:const EdgeInsets.all(14),child:Column(children:[_toggleRow('الصوت',sound,(v)=>setState(()=>sound=v)),_toggleRow('الحفظ التلقائي',autoSave,(v)=>setState(()=>autoSave=v)),_toggleRow('الحركة الناعمة',smooth,(v)=>setState(()=>smooth=v)),ListTile(title:const Text('الثيم'),subtitle:Text(themes.firstWhere((x)=>x['id']==boardTheme)['name']!),trailing:const Icon(Icons.chevron_left,color:AppTheme.goldBright),onTap:()=>nav('store'))])));
  Widget _toggleRow(String title,bool value,ValueChanged<bool> on)=>SwitchListTile(value:value,onChanged:on,title:Text(title),activeColor:AppTheme.goldBright,contentPadding:EdgeInsets.zero);

  Widget _account(){final next=level*100;return _page('الحساب',Container(decoration:Ui.panel(),padding:const EdgeInsets.all(16),child:Column(children:[const CircleAvatar(radius:34,backgroundColor:Color(0xFF172B2E),child:Text('♛',style:TextStyle(fontSize:30,color:AppTheme.goldBright))),const SizedBox(height:10),Text(playerName,style:AppTheme.amiri(22)),Text('المستوى $level · $xp XP',style:const TextStyle(color:AppTheme.muted)),const SizedBox(height:12),LinearProgressIndicator(value:(xp%next)/next,backgroundColor:Colors.white10,color:AppTheme.goldBright),const SizedBox(height:14),TextField(controller:TextEditingController(text:playerName),onChanged:(v)=>playerName=v,textAlign:TextAlign.center,decoration:const InputDecoration(labelText:'اسم اللاعب')),const SizedBox(height:12),_button('حفظ الحساب',_save),const SizedBox(height:14),Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[_metricSmall('مباريات','$games'),_metricSmall('فوز','$wins'),_metricSmall('خسارة','$losses'),_metricSmall('تعادل','$draws')])])));}
  Widget _metricSmall(String a,String b)=>Column(children:[Text(b,style:AppTheme.amiri(19,color:AppTheme.goldBright)),Text(a,style:const TextStyle(fontSize:9,color:AppTheme.muted))]);

  Widget _store()=>_page('المتجر',Column(children:[Row(children:[Expanded(child:_wallet('ذهب',gold,'●')),Expanded(child:_wallet('جواهر',gems,'◆'))]),const SizedBox(height:10),const Align(alignment:Alignment.centerRight,child:Text('أشكال القطع',style:TextStyle(color:AppTheme.goldBright,fontWeight:FontWeight.w900))),const SizedBox(height:8),GridView.count(crossAxisCount:3,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisSpacing:8,mainAxisSpacing:8,children:[for(final id in pieceSkins)_shopItem(id)]),const SizedBox(height:14),const Align(alignment:Alignment.centerRight,child:Text('ثيم الرقعة',style:TextStyle(color:AppTheme.goldBright,fontWeight:FontWeight.w900))),const SizedBox(height:8),GridView.count(crossAxisCount:3,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisSpacing:8,mainAxisSpacing:8,children:[for(final t in themes)_themeItem(t)]),const SizedBox(height:14),const Align(alignment:Alignment.centerRight,child:Text('إطارات الحساب',style:TextStyle(color:AppTheme.goldBright,fontWeight:FontWeight.w900))),const SizedBox(height:8),Wrap(spacing:8,runSpacing:8,children:[for(final x in frames)_buyableOwned(x[0] as String,x[1] as String,x[2] as String,x[3] as int,activeFrame==x[0],ownedFrames,()=>setState(()=>activeFrame=x[0] as String))]),const SizedBox(height:14),const Align(alignment:Alignment.centerRight,child:Text('المؤثرات',style:TextStyle(color:AppTheme.goldBright,fontWeight:FontWeight.w900))),const SizedBox(height:8),Wrap(spacing:8,runSpacing:8,children:[for(final x in effects)_buyableOwned(x[0] as String,x[1] as String,x[2] as String,x[3] as int,activeEffect==x[0],ownedEffects,()=>setState(()=>activeEffect=x[0] as String))])]));
  Widget _wallet(String t,int value,String icon)=>Container(margin:const EdgeInsets.all(4),padding:const EdgeInsets.all(10),decoration:Ui.panel(radius:12),child:Row(mainAxisAlignment:MainAxisAlignment.center,children:[Text(icon,style:const TextStyle(color:AppTheme.goldBright)),const SizedBox(width:6),Text('$value $t',style:const TextStyle(fontSize:10,fontWeight:FontWeight.w900))]));
  Widget _shopItem(String id)=>InkWell(onTap:(){if(!ownedPieces.contains(id)){final price={'gold':1200,'onyx':1800,'emerald':2200,'ice':3000,'violet':3600}[id]??0;if(gold<price){_showMessage('الرصيد غير كافٍ');return;}gold-=price;ownedPieces.add(id);}setState(()=>pieceSkin=id);_save();},borderRadius:BorderRadius.circular(14),child:Container(padding:const EdgeInsets.all(8),decoration:BoxDecoration(color:Colors.white.withOpacity(.025),borderRadius:BorderRadius.circular(14),border:Border.all(color:pieceSkin==id?AppTheme.goldBright:Colors.white.withOpacity(.08))),child:Column(children:[Expanded(child:Center(child:Text('♛',style:TextStyle(fontSize:38,color:_pieceTintFor(id))))),Text(id,style:const TextStyle(fontSize:8)),Text(pieceSkin==id?'✓ مستخدم':'اختيار',style:const TextStyle(fontSize:8,color:AppTheme.goldBright))])));
  Color _pieceTintFor(String id)=>switch(id){'gold'=>const Color(0xFFFFE49A),'emerald'=>const Color(0xFF8DFFA0),'ice'=>const Color(0xFFBDEBFF),'violet'=>const Color(0xFFE5C9FF),'onyx'=>const Color(0xFFB9B9B9),_=>Colors.white};
  Widget _buyable(String title,String rarity,int price,bool active,VoidCallback tap)=>InkWell(onTap:(){if(active){tap();return;}if(gold<price){_showMessage('الرصيد غير كافٍ');return;}setState(()=>gold-=price);tap();_save();},child:Container(width:150,padding:const EdgeInsets.all(10),decoration:Ui.panel(radius:12),child:Column(children:[Text(title,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:11)),Text(rarity,style:const TextStyle(fontSize:9,color:AppTheme.muted)),const SizedBox(height:6),Text(active?'✓ مستخدم':'🪙 $price',style:const TextStyle(color:AppTheme.goldBright,fontSize:10))])));
  Widget _buyableOwned(String id,String title,String rarity,int price,bool active,Set<String> owned,VoidCallback tap)=>InkWell(onTap:(){if(!owned.contains(id)){if(gold<price){_showMessage('الرصيد غير كافٍ');return;}gold-=price;owned.add(id);}tap();_save();},child:Container(width:150,padding:const EdgeInsets.all(10),decoration:Ui.panel(radius:12),child:Column(children:[Text(title,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:11)),Text(rarity,style:const TextStyle(fontSize:9,color:AppTheme.muted)),const SizedBox(height:6),Text(active?'✓ مستخدم':owned.contains(id)?'اختيار':'🪙 $price',style:const TextStyle(color:AppTheme.goldBright,fontSize:10))])));
  Widget _themeItem(Map<String,String> t)=>InkWell(onTap:(){final id=t['id']!;if(!ownedThemes.contains(id)){final price={'emerald':750,'ruby':1050,'night':1200,'violet':900,'rosegold':1100,'obsidian':1350,'ocean':950,'forest':850,'crimson':1100,'slate':800,'copper':950}[id]??1000;if(gold<price){_showMessage('الرصيد غير كافٍ');return;}gold-=price;ownedThemes.add(id);}setState(()=>boardTheme=id);_save();},child:Container(padding:const EdgeInsets.all(8),decoration:BoxDecoration(borderRadius:BorderRadius.circular(12),border:Border.all(color:boardTheme==t['id']?AppTheme.goldBright:Colors.white.withOpacity(.08))),child:Column(children:[Expanded(child:Container(decoration:BoxDecoration(borderRadius:BorderRadius.circular(7),gradient:LinearGradient(colors:[_hex(t['l']!),_hex(t['d']!)])))),const SizedBox(height:5),Text(t['name']!,style:const TextStyle(fontSize:8))])));

  Widget _achievements()=>_page('الإنجازات',Column(children:[_progressCard('أول انتصار',wins>0,1),_progressCard('5 مباريات',games>=5,5),_progressCard('10 مباريات',games>=10,10),_progressCard('كش مات',checkmates>0,1),_progressCard('جامع القطع',captures>=10,10)]));
  Widget _progressCard(String title,bool done,int goal)=>Container(margin:const EdgeInsets.only(bottom:8),padding:const EdgeInsets.all(14),decoration:Ui.panel(radius:14),child:Row(children:[Icon(done?Icons.check_circle:Icons.emoji_events,color:done?AppTheme.green:AppTheme.goldBright),const SizedBox(width:10),Expanded(child:Text(title,style:const TextStyle(fontWeight:FontWeight.w800))),Text(done?'مكتمل':'0/$goal',style:const TextStyle(color:AppTheme.muted))]));
  Widget _tasks()=>_page('المهام اليومية',Column(children:[_task('العب مباراتين',min(games,2),2,100),_task('التقط 10 قطع',min(captures,10),10,100),_task('اربح مباراة',min(wins,1),1,150),const SizedBox(height:10),const Align(alignment:Alignment.centerRight,child:Text('المهام طويلة المدى',style:TextStyle(color:AppTheme.goldBright,fontWeight:FontWeight.w900))),const SizedBox(height:8),_task('العب 50 مباراة',min(games,50),50,1000)]));
  Widget _task(String title,int value,int goal,int reward)=>Container(margin:const EdgeInsets.only(bottom:8),padding:const EdgeInsets.all(14),decoration:Ui.panel(radius:14),child:Column(children:[Row(children:[Expanded(child:Text(title,style:const TextStyle(fontWeight:FontWeight.w800))),Text('+$reward XP',style:const TextStyle(color:AppTheme.goldBright))]),const SizedBox(height:8),LinearProgressIndicator(value:value/goal,backgroundColor:Colors.white10,color:AppTheme.goldBright),const SizedBox(height:4),Align(alignment:Alignment.centerLeft,child:Text('$value / $goal',style:const TextStyle(fontSize:9,color:AppTheme.muted)))]));
  Widget _stats()=>_page('الإحصائيات',Column(children:[GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisSpacing:8,mainAxisSpacing:8,children:[_metric('المباريات','$games'),_metric('الفوز','$wins'),_metric('الخسارة','$losses'),_metric('التعادل','$draws'),_metric('القطع المأخوذة','$captures'),_metric('XP','$xp')]),const SizedBox(height:12),Container(decoration:Ui.panel(),padding:const EdgeInsets.all(14),child:Column(children:[const Align(alignment:Alignment.centerRight,child:Text('الاقتصاد',style:TextStyle(color:AppTheme.goldBright,fontWeight:FontWeight.w900))),const SizedBox(height:10),_settingRow('الذهب','$gold'),_settingRow('الجواهر','$gems')]))]));
  Widget _metric(String a,String b)=>Container(decoration:Ui.panel(radius:14),padding:const EdgeInsets.all(14),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(b,style:AppTheme.amiri(24,color:AppTheme.goldBright)),Text(a,style:const TextStyle(color:AppTheme.muted,fontSize:10))]));
  Widget _settingRow(String a,String b)=>Padding(padding:const EdgeInsets.symmetric(vertical:8),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(a,style:const TextStyle(fontWeight:FontWeight.w800)),Text(b,style:const TextStyle(color:AppTheme.goldBright))]));
  Widget _map(){
    final items=<Widget>[];
    for(var i=1;i<=10;i++){
      final unlocked=i<=max(1,min(10,wins+1));
      items.add(Container(margin:const EdgeInsets.only(bottom:8),padding:const EdgeInsets.all(10),decoration:Ui.panel(radius:14),child:Row(children:[Container(width:48,height:48,decoration:BoxDecoration(shape:BoxShape.circle,border:Border.all(color:unlocked?AppTheme.goldBright:AppTheme.gold.withOpacity(.25),width:2)),alignment:Alignment.center,child:Text('$i',style:const TextStyle(fontWeight:FontWeight.w900))),const SizedBox(width:12),Expanded(child:Text(i==1?'البداية':'مرحلة ${['المبتدئ','الأساسيات','التكتيك','المتقدم'][i%4]}',style:const TextStyle(fontWeight:FontWeight.w800))),Text(unlocked?'متاح':'مغلق',style:TextStyle(fontSize:9,color:unlocked?AppTheme.green:AppTheme.muted))])));
    }
    return _page('خريطة المراحل',Column(children:items));
  }

  Widget _online()=>_page('اللعب أونلاين',Column(children:[_card('إنشاء غرفة','أنشئ غرفة وشارك الرمز',Icons.add_box,_createRoom),_card('الانضمام لغرفة','أدخل رمز الغرفة',Icons.login,_joinRoom),_card('مطابقة عشوائية','العثور على خصم تلقائيًا',Icons.shuffle,_randomMatch),const SizedBox(height:8),const Text('الأونلاين يعتمد Firebase Realtime Database. أضف إعداد Firebase للمشروع قبل البناء.',textAlign:TextAlign.center,style:TextStyle(fontSize:10,color:AppTheme.muted))]));
  Future<void> _createRoom() async{final id='${100000+random.nextInt(899999)}';try{state=ChessState.initial();online=OnlineService(id);await online!.create(fen:state.toFen(),hostColor:'white');roomId=id;onlineHost=true;mode='online';_startGame();roomId=id;onlineHost=true;_listenOnline();if(mounted)showDialog(context:context,builder:(c)=>AlertDialog(backgroundColor:AppTheme.onyx2,title:Text('رمز الغرفة',style:AppTheme.amiri(20)),content:SelectableText(id,textAlign:TextAlign.center,style:AppTheme.amiri(30,color:AppTheme.goldBright)),actions:[TextButton(onPressed:(){Navigator.pop(c);},child:const Text('بدء'))]));}catch(e){_showMessage('تعذر الاتصال بـ Firebase. أضف إعدادات Firebase أولًا.');}}
  Future<void> _joinRoom() async{final c=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(d)=>AlertDialog(backgroundColor:AppTheme.onyx2,title:Text('الانضمام لغرفة',style:AppTheme.amiri(20)),content:TextField(controller:c,textAlign:TextAlign.center,keyboardType:TextInputType.number,decoration:const InputDecoration(hintText:'رمز الغرفة')),actions:[TextButton(onPressed:()=>Navigator.pop(d,false),child:const Text('إلغاء')),TextButton(onPressed:()=>Navigator.pop(d,true),child:const Text('انضم'))]));if(ok!=true||c.text.trim().isEmpty)return;try{roomId=c.text.trim();online=OnlineService(roomId!);final snap=await online!.room.get();if(!snap.exists)throw Exception('room');final data=Map<String,dynamic>.from(snap.value as Map);state=ChessState.fromFen(data['fen'] as String);mode='online';onlineHost=false;roomId=c.text.trim();_startOnlineGameWithoutReset();_listenOnline();}catch(_){_showMessage('الغرفة غير موجودة أو Firebase غير جاهز.');}}
  Future<void> _randomMatch() async {
    if(matchSearching)return;
    try{
      matchPlayerId='${DateTime.now().microsecondsSinceEpoch}_${random.nextInt(99999)}';
      online=OnlineService('matchmaking'); matchSearching=true;
      final result=await online!.findMatch(playerId:matchPlayerId!,fen:ChessState.initial().toFen());
      if(result.roomId!=null){await _enterMatchedRoom(result.roomId!,result.opponentId!);return;}
      queueSub?.cancel();
      queueSub=online!.watchMatchmaking().listen((event){
        final v=event.snapshot.value;
        if(!matchSearching||v is! Map)return;
        if(v['p1']?.toString()==matchPlayerId&&v['p2']!=null&&v['roomId']!=null){
          _enterMatchedRoom(v['roomId'].toString(),v['p2'].toString());
        }
      });
      _showMessage('جاري البحث عن خصم…');
    }catch(_){matchSearching=false;_showMessage('تعذر بدء المطابقة. تحقق من إعداد Firebase.');}
  }
  Future<void> _enterMatchedRoom(String room,String opponent) async {
    if(!matchSearching)return; matchSearching=false; queueSub?.cancel();
    final ids=[matchPlayerId!,opponent]..sort(); final host=ids.first==matchPlayerId;
    final service=OnlineService(room);
    try{await service.create(fen:ChessState.initial().toFen(),hostColor:host?'white':'black');}catch(_){}
    roomId=room;online=service;onlineHost=host;mode='online';
    if(!host)await service.setJoined(color:'black');
    _startGame(); _listenOnline();
  }

  void _startOnlineGameWithoutReset(){
    history..clear()..add(_positionKey(state)); moveHistory.clear();selected=null;
    whiteSeconds=blackSeconds=selectedMinutes*60;flipped=false;paused=false;aiThinking=false;onlineSeq=0;nav('game');
  }
  void _listenOnline(){onlineSub?.cancel();if(online==null)return;onlineSub=online!.watch().listen((event){final value=event.snapshot.value;if(value is! Map)return;final moves=value['moves'];if(moves is Map){for(final e in moves.entries){final seq=int.tryParse('${e.key}')??0;if(seq>onlineSeq){final uci='${e.value}';final legal=ChessEngine.allLegal(state,state.turn);final m=legal.where((x)=>x.uci==uci).firstOrNull;if(m!=null){onlineSeq=seq;_commitMove(m,remote:true);}}}}});}
  void _showMessage(String message)=>showDialog(context:context,builder:(c)=>AlertDialog(backgroundColor:AppTheme.onyx2,content:Text(message),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('حسنًا'))]));
}

extension FirstOrNull<T> on Iterable<T>{T? get firstOrNull=>isEmpty?null:first;}
