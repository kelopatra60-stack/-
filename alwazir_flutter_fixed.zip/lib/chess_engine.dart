enum ColorSide { white, black }

enum PieceType { pawn, knight, bishop, rook, queen, king }

class Square {
  final int r, c;
  const Square(this.r, this.c);
  String get algebraic => '${String.fromCharCode(97 + c)}${8 - r}';
  @override bool operator ==(Object o) => o is Square && o.r == r && o.c == c;
  @override int get hashCode => Object.hash(r, c);
}

class Move {
  final Square from, to;
  final bool capture, enPassant, doubleStep;
  final String? castle;
  final PieceType? promotion;
  const Move({required this.from, required this.to, this.capture=false, this.enPassant=false, this.doubleStep=false, this.castle, this.promotion});
  String get uci => '${from.algebraic}${to.algebraic}${promotion == null ? '' : promotionChar(promotion!)}';
}

class ChessState {
  final List<List<String?>> board;
  final ColorSide turn;
  final bool wk, wq, bk, bq;
  final Square? ep;
  final int halfmove, fullmove;
  ChessState({required this.board, this.turn=ColorSide.white, this.wk=true, this.wq=true, this.bk=true, this.bq=true, this.ep, this.halfmove=0, this.fullmove=1});
  ChessState clone() => ChessState(board: List.generate(8,(r)=>List<String?>.from(board[r])),turn:turn,wk:wk,wq:wq,bk:bk,bq:bq,ep:ep==null?null:Square(ep!.r,ep!.c),halfmove:halfmove,fullmove:fullmove);
  static ChessState initial(){
    const order=['r','n','b','q','k','b','n','r'];
    final b=List.generate(8,(_)=>List<String?>.filled(8,null));
    for(var c=0;c<8;c++){b[0][c]=order[c];b[1][c]='p';b[6][c]='P';b[7][c]=order[c].toUpperCase();}
    return ChessState(board:b);
  }
  String toFen(){
    final ranks=<String>[];
    for(var r=0;r<8;r++){var empty=0;var out='';for(var c=0;c<8;c++){final p=board[r][c];if(p==null){empty++;}else{if(empty>0){out+=empty.toString();empty=0;}out+=p;}}if(empty>0)out+=empty.toString();ranks.add(out);}
    final cast='${wk?'K':''}${wq?'Q':''}${bk?'k':''}${bq?'q':''}';
    return '${ranks.join('/')} ${turn==ColorSide.white?'w':'b'} ${cast.isEmpty?'-':cast} ${ep?.algebraic??'-'} $halfmove $fullmove';
  }
  static ChessState fromFen(String fen){
    final p=fen.trim().split(RegExp(r'\s+'));if(p.length<4)throw const FormatException('Invalid FEN');
    final rows=p[0].split('/');if(rows.length!=8)throw const FormatException('Invalid FEN board');
    final b=List.generate(8,(_)=>List<String?>.filled(8,null));
    for(var r=0;r<8;r++){var c=0;for(final ch in rows[r].split('')){if(RegExp(r'^[1-8]$').hasMatch(ch)){c+=int.parse(ch);}else if('pnbrqkPNBRQK'.contains(ch)&&c<8){b[r][c++]=ch;}else{throw const FormatException('Invalid FEN rank');}}if(c!=8)throw const FormatException('Invalid FEN rank');}
    final side=p[1]=='w'?ColorSide.white:ColorSide.black;
    final cast=p[2];
    final ep=p[3]=='-'?null:squareFromAlgebraic(p[3]);
    return ChessState(board:b,turn:side,wk:cast.contains('K'),wq:cast.contains('Q'),bk:cast.contains('k'),bq:cast.contains('q'),ep:ep,halfmove:p.length>4?int.parse(p[4]):0,fullmove:p.length>5?int.parse(p[5]):1);
  }
}

String? pieceColor(String? p)=>p==null?null:(p==p.toUpperCase()?'w':'b');
PieceType typeOf(String p)=>const {'p':PieceType.pawn,'n':PieceType.knight,'b':PieceType.bishop,'r':PieceType.rook,'q':PieceType.queen,'k':PieceType.king}[p.toLowerCase()]!;
String promotionChar(PieceType p)=>const {PieceType.queen:'q',PieceType.rook:'r',PieceType.bishop:'b',PieceType.knight:'n'}[p]!;
Square squareFromAlgebraic(String s){if(s.length!=2)throw const FormatException('Invalid square');final file=s.codeUnitAt(0)-97;final rank=int.tryParse(s[1]);if(file<0||file>7||rank==null||rank<1||rank>8)throw const FormatException('Invalid square');return Square(8-rank,file);}

class GameStatus {
  final String status; final ColorSide? winner;
  const GameStatus(this.status,[this.winner]);
  bool get over=>const {'checkmate','stalemate','fifty_move','threefold','insufficient'}.contains(status);
}

class ChessEngine {
  static const dirsB=[[-1,-1],[-1,1],[1,-1],[1,1]];
  static const dirsR=[[-1,0],[1,0],[0,-1],[0,1]];
  static const dirsN=[[-2,-1],[-2,1],[2,-1],[2,1],[-1,-2],[-1,2],[1,-2],[1,2]];
  static const dirsK=[[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]];
  static bool inBounds(int r,int c)=>r>=0&&r<8&&c>=0&&c<8;
  static Square? findKing(ChessState s,ColorSide side){final k=side==ColorSide.white?'K':'k';for(var r=0;r<8;r++)for(var c=0;c<8;c++)if(s.board[r][c]==k)return Square(r,c);return null;}
  static bool attacked(ChessState s,int r,int c,ColorSide by){
    final color=by==ColorSide.white?'w':'b';
    final pawnRow=r+(by==ColorSide.white?1:-1);
    for(final dc in [-1,1]){final cc=c+dc;if(inBounds(pawnRow,cc)&&s.board[pawnRow][cc]?.toLowerCase()=='p'&&pieceColor(s.board[pawnRow][cc])==color)return true;}
    for(final d in dirsN){final rr=r+d[0],cc=c+d[1];if(inBounds(rr,cc)&&s.board[rr][cc]?.toLowerCase()=='n'&&pieceColor(s.board[rr][cc])==color)return true;}
    for(final d in dirsK){final rr=r+d[0],cc=c+d[1];if(inBounds(rr,cc)&&s.board[rr][cc]?.toLowerCase()=='k'&&pieceColor(s.board[rr][cc])==color)return true;}
    bool ray(List<List<int>> dirs,List<String> pieces){for(final d in dirs){var rr=r+d[0],cc=c+d[1];while(inBounds(rr,cc)){final p=s.board[rr][cc];if(p!=null){if(pieceColor(p)==color&&pieces.contains(p.toLowerCase()))return true;break;}rr+=d[0];cc+=d[1];}}return false;}
    return ray(dirsB,['b','q'])||ray(dirsR,['r','q']);
  }
  static bool inCheck(ChessState s,ColorSide side){final k=findKing(s,side);return k!=null&&attacked(s,k.r,k.c,side==ColorSide.white?ColorSide.black:ColorSide.white);}
  static List<Move> pseudo(ChessState s,int r,int c,{bool includePromotions=true}){
    final p=s.board[r][c];if(p==null)return const[];final side=pieceColor(p)=='w'?ColorSide.white:ColorSide.black;final out=<Move>[];final t=p.toLowerCase();
    void add(int rr,int cc,{bool capture=false,bool ep=false,bool dbl=false,String? castle,PieceType? promotion}){if(!inBounds(rr,cc))return;final x=s.board[rr][cc];if(x!=null&&pieceColor(x)==pieceColor(p))return;out.add(Move(from:Square(r,c),to:Square(rr,cc),capture:capture||x!=null,enPassant:ep,doubleStep:dbl,castle:castle,promotion:promotion));}
    void pawnAdd(int rr,int cc,{bool capture=false,bool ep=false,bool dbl=false}){final promoRank=side==ColorSide.white?0:7;if(rr==promoRank&&includePromotions){for(final q in [PieceType.queen,PieceType.rook,PieceType.bishop,PieceType.knight])add(rr,cc,capture:capture,ep:ep,dbl:dbl,promotion:q);}else{add(rr,cc,capture:capture,ep:ep,dbl:dbl);}}
    if(t=='p'){
      final dir=side==ColorSide.white?-1:1,start=side==ColorSide.white?6:1,rr=r+dir;
      if(inBounds(rr,c)&&s.board[rr][c]==null){pawnAdd(rr,c);if(r==start&&s.board[r+2*dir][c]==null)add(r+2*dir,c,dbl:true);}
      for(final dc in [-1,1]){final cc=c+dc;if(!inBounds(rr,cc))continue;final x=s.board[rr][cc];if(x!=null&&pieceColor(x)!=pieceColor(p))pawnAdd(rr,cc,capture:true);else if(s.ep?.r==rr&&s.ep?.c==cc)pawnAdd(rr,cc,capture:true,ep:true);}
    } else if(t=='n') {for(final d in dirsN)add(r+d[0],c+d[1]);}
    else if(t=='k'){
      for(final d in dirsK)add(r+d[0],c+d[1]);
      if(r==(side==ColorSide.white?7:0)&&c==4&&!inCheck(s,side)){
        final opp=side==ColorSide.white?ColorSide.black:ColorSide.white,rank=r;
        final kRights=side==ColorSide.white?s.wk:s.bk,qRights=side==ColorSide.white?s.wq:s.bq;
        if(kRights&&s.board[rank][5]==null&&s.board[rank][6]==null&&s.board[rank][7]?.toLowerCase()=='r'&&!attacked(s,rank,5,opp)&&!attacked(s,rank,6,opp))add(rank,6,castle:'k');
        if(qRights&&s.board[rank][3]==null&&s.board[rank][2]==null&&s.board[rank][1]==null&&s.board[rank][0]?.toLowerCase()=='r'&&!attacked(s,rank,3,opp)&&!attacked(s,rank,2,opp))add(rank,2,castle:'q');
      }
    } else {
      final dirs=t=='b'?dirsB:t=='r'?dirsR:[...dirsB,...dirsR];
      for(final d in dirs){var rr=r+d[0],cc=c+d[1];while(inBounds(rr,cc)){final x=s.board[rr][cc];if(x==null){add(rr,cc);}else{if(pieceColor(x)!=pieceColor(p))add(rr,cc,capture:true);break;}rr+=d[0];cc+=d[1];}}
    }
    return out;
  }
  static ChessState apply(ChessState s,Move m){
    final n=s.clone(),b=n.board,p=b[m.from.r][m.from.c]!;final side=pieceColor(p)=='w'?ColorSide.white:ColorSide.black;final captured=b[m.to.r][m.to.c];
    if(m.enPassant){final dr=side==ColorSide.white?1:-1;b[m.to.r+dr][m.to.c]=null;}
    if(m.castle=='k'){b[m.from.r][5]=b[m.from.r][7];b[m.from.r][7]=null;}
    if(m.castle=='q'){b[m.from.r][3]=b[m.from.r][0];b[m.from.r][0]=null;}
    b[m.from.r][m.from.c]=null;b[m.to.r][m.to.c]=p;
    if(m.promotion!=null)b[m.to.r][m.to.c]=side==ColorSide.white?promotionChar(m.promotion!).toUpperCase():promotionChar(m.promotion!);
    if(p.toLowerCase()=='k'){if(side==ColorSide.white){n.wk=false;n.wq=false;}else{n.bk=false;n.bq=false;}}
    if(p.toLowerCase()=='r'){_removeRookRight(n,m.from.r,m.from.c);}
    if(captured?.toLowerCase()=='r'){_removeRookRight(n,m.to.r,m.to.c);}
    n.ep=m.doubleStep?Square(m.from.r+(side==ColorSide.white?-1:1),m.from.c):null;
    n.halfmove=(p.toLowerCase()=='p'||captured!=null||m.enPassant)?0:s.halfmove+1;
    n.turn=side==ColorSide.white?ColorSide.black:ColorSide.white;if(side==ColorSide.black)n.fullmove++;
    return n;
  }
  static void _removeRookRight(ChessState n,int r,int c){if(r==7&&c==0)n.wq=false;if(r==7&&c==7)n.wk=false;if(r==0&&c==0)n.bq=false;if(r==0&&c==7)n.bk=false;}
  static List<Move> legal(ChessState s,int r,int c){final p=s.board[r][c];if(p==null)return const[];final side=pieceColor(p)=='w'?ColorSide.white:ColorSide.black;if(side!=s.turn)return const[];return pseudo(s,r,c).where((m)=>!inCheck(apply(s,m),side)).toList();}
  static List<Move> allLegal(ChessState s,ColorSide side){final out=<Move>[];for(var r=0;r<8;r++)for(var c=0;c<8;c++){final p=s.board[r][c];if(p!=null&&pieceColor(p)==(side==ColorSide.white?'w':'b')){for(final m in pseudo(s,r,c)){if(!inCheck(apply(s,m),side))out.add(m);}}}return out;}
  static bool insufficientMaterial(ChessState s){
    final pieces=<String>[];for(final row in s.board)for(final p in row)if(p!=null&&p.toLowerCase()!='k')pieces.add(p);
    if(pieces.any((p)=>['p','q','r'].contains(p.toLowerCase())))return false;
    if(pieces.isEmpty)return true;
    if(pieces.length==1&&['b','n'].contains(pieces[0].toLowerCase()))return true;
    if(pieces.every((p)=>p.toLowerCase()=='b')&&pieces.length==2){final colors=<int>[];for(var r=0;r<8;r++)for(var c=0;c<8;c++)if(s.board[r][c]?.toLowerCase()=='b')colors.add((r+c)%2);return colors.length==2&&colors[0]==colors[1];}
    return false;
  }
  static GameStatus status(ChessState s,{List<String>? positionHistory}){
    if(s.halfmove>=100)return const GameStatus('fifty_move');
    if(insufficientMaterial(s))return const GameStatus('insufficient');
    final moves=allLegal(s,s.turn),check=inCheck(s,s.turn);
    if(moves.isEmpty)return check?GameStatus('checkmate',s.turn==ColorSide.white?ColorSide.black:ColorSide.white):const GameStatus('stalemate');
    final key=s.toFen().split(' ').sublist(0,4).join(' ');final h=positionHistory??const <String>[];if(h.where((e)=>e==key).length>=3)return const GameStatus('threefold');
    return check?const GameStatus('check'):const GameStatus('normal');
  }
}
