import 'package:firebase_database/firebase_database.dart';

class MatchResult {
  final bool waiting;
  final String? opponentId;
  final String? roomId;
  const MatchResult.waiting():waiting=true,opponentId=null,roomId=null;
  const MatchResult.matched(this.opponentId,this.roomId):waiting=false;
}

class OnlineService {
  final String roomId;
  final DatabaseReference root;
  OnlineService(this.roomId) : root = FirebaseDatabase.instance.ref('alwazir');

  DatabaseReference get room => root.child('rooms').child(roomId);
  DatabaseReference get queue => root.child('matchmaking').child('current');

  Future<void> create({required String fen, required String hostColor}) => room.set({
    'fen': fen, 'hostColor': hostColor, 'guestColor': hostColor == 'white' ? 'black' : 'white',
    'updatedAt': ServerValue.timestamp, 'moves': {}, 'status': 'waiting',
  });

  Future<void> setJoined({required String color}) => room.update({
    'guestColor': color, 'status': 'playing', 'updatedAt': ServerValue.timestamp,
  });

  Future<void> writeMove(int seq, String uci, String fen) => room.update({
    'moves/$seq': uci, 'fen': fen, 'updatedAt': ServerValue.timestamp, 'status': 'playing',
  });

  Future<void> setPresence(String color, bool online) => room.child('presence/$color').set(online);
  Stream<DatabaseEvent> watch() => room.onValue;
  Future<DataSnapshot> read() => room.get();
  Future<void> delete() => room.remove();

  /// Atomically places a player in the single matchmaking slot. The first
  /// player waits; the second player claims the slot and both derive the same
  /// deterministic room id from the two player ids.
  Future<MatchResult> findMatch({required String playerId, required String fen}) async {
    final tx = await queue.runTransaction((current) {
      Map<String,dynamic> value = {};
      if (current is Map) value = Map<String,dynamic>.from(current);
      final p1 = value['p1']?.toString();
      final p2 = value['p2']?.toString();
      if (p1 == null) {
        value['p1'] = playerId;
        value['fen1'] = fen;
        value['createdAt'] = ServerValue.timestamp;
        return Transaction.success(value);
      }
      if (p1 == playerId || p2 != null) return Transaction.abort();
      final a = p1.compareTo(playerId) < 0 ? p1 : playerId;
      final b = p1.compareTo(playerId) < 0 ? playerId : p1;
      value['p2'] = playerId;
      value['roomId'] = 'match_${a}_$b';
      return Transaction.success(value);
    });
    if (tx.committed) {
      final data = tx.snapshot.value;
      if (data is Map && data['p1'] != null && data['p2'] != null) {
        return MatchResult.matched(data['p1'].toString() == playerId ? data['p2'].toString() : data['p1'].toString(), data['roomId'].toString());
      }
    }
    final first = await queue.get();
    final v = first.value;
    if (v is Map && v['p1']?.toString() == playerId && v['p2'] == null) {
      await queue.update({'fen1':fen,'createdAt':ServerValue.timestamp});
      return const MatchResult.waiting();
    }
    return const MatchResult.waiting();
  }

  Future<void> clearMatchmaking() => queue.remove();
  Stream<DatabaseEvent> watchMatchmaking() => queue.onValue;
}
