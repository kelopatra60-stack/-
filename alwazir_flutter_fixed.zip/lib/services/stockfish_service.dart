import 'dart:async';
import 'package:stockfish/stockfish.dart';

class StockfishService {
  Stockfish? _engine;
  StreamSubscription<String>? _sub;
  final _out = StreamController<String>.broadcast();
  Completer<String?>? _bestMove;
  bool _ready = false;
  Stream<String> get output => _out.stream;

  Future<void> init() async {
    if (_engine != null && _ready) return;
    _engine = Stockfish();
    if (_engine == null) throw StateError('Stockfish instance is already active');
    _sub?.cancel();
    _sub = _engine!.stdout.listen((line) {
      _out.add(line);
      if (line.contains('readyok')) _ready = true;
      if (line.startsWith('bestmove ')) {
        final parts = line.trim().split(RegExp(r'\s+'));
        final move = parts.length > 1 && parts[1] != '(none)' ? parts[1] : null;
        final c = _bestMove;
        _bestMove = null;
        if (c != null && !c.isCompleted) c.complete(move);
      }
    });
    _engine!.stdin = 'uci';
    await _waitFor('uciok');
    _engine!.stdin = 'isready';
    await _waitFor('readyok');
  }

  Future<void> _waitFor(String token) async {
    if (token == 'readyok' && _ready) return;
    await output.firstWhere((line) => line.contains(token)).timeout(const Duration(seconds: 8));
  }

  Future<String?> bestMove(String fen, {required int skill, required int movetime}) async {
    await init();
    _bestMove?.complete(null);
    final completer = Completer<String?>();
    _bestMove = completer;
    final sf = _engine!;
    sf.stdin = 'stop';
    sf.stdin = 'setoption name Skill Level value ${skill.clamp(0, 20)}';
    sf.stdin = 'position fen $fen';
    sf.stdin = 'go movetime $movetime';
    return completer.future.timeout(Duration(milliseconds: movetime + 4000), onTimeout: () {
      if (_bestMove == completer) _bestMove = null;
      return null;
    });
  }

  void dispose() {
    try { _engine?.stdin = 'quit'; } catch (_) {}
    _sub?.cancel();
    try { _engine?.dispose(); } catch (_) {}
    _engine = null;
    _ready = false;
    _sub = null;
    // Do not close the broadcast controller: the service can be initialized again
    // after a game or screen is disposed.
  }
}
