import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  Future<String?> get(String key) async => (await SharedPreferences.getInstance()).getString(key);
  Future<void> set(String key, String value) async => (await SharedPreferences.getInstance()).setString(key, value);
  Future<int> intValue(String key, int fallback) async => (await SharedPreferences.getInstance()).getInt(key) ?? fallback;
  Future<void> setInt(String key, int value) async => (await SharedPreferences.getInstance()).setInt(key, value);
  Future<List<String>> stringList(String key) async => (await SharedPreferences.getInstance()).getStringList(key) ?? <String>[];
  Future<void> setStringList(String key, List<String> value) async => (await SharedPreferences.getInstance()).setStringList(key, value);
}
