import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static const onyx1 = Color(0xFF0D1A1C);
  static const onyx2 = Color(0xFF16292C);
  static const bg = Color(0xFF060F11);
  static const boardLight = Color(0xFFE9DFC9);
  static const boardDark = Color(0xFF5B4636);
  static const gold = Color(0xFFC68A3D);
  static const goldBright = Color(0xFFE8AC5A);
  static const cream = Color(0xFFECE1C8);
  static const danger = Color(0xFFB5533F);
  static const green = Color(0xFF55C98A);
  static const muted = Color(0xFF93A29C);
  static const text = Color(0xFFF0E6CD);

  static ThemeData get data {
    final base = ThemeData.dark(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: base.colorScheme.copyWith(
        primary: goldBright,
        secondary: gold,
        surface: onyx2,
        error: danger,
      ),
      textTheme: GoogleFonts.cairoTextTheme(base.textTheme).apply(
        bodyColor: cream,
        displayColor: cream,
      ),
      splashFactory: InkRipple.splashFactory,
    );
  }

  static TextStyle amiri(double size, {Color? color, FontWeight? weight}) =>
      GoogleFonts.amiri(fontSize: size, color: color ?? cream, fontWeight: weight ?? FontWeight.w600);
}

class Ui {
  static BoxDecoration panel({double radius = 16}) => BoxDecoration(
    gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF16292C), Color(0xFF101F22)]),
    border: Border.all(color: Colors.white.withOpacity(.06)),
    borderRadius: BorderRadius.circular(radius),
    boxShadow: [BoxShadow(color: Colors.black.withOpacity(.20), blurRadius: 30, offset: const Offset(0, 10))],
  );

  static BoxDecoration goldButton({double radius = 12}) => BoxDecoration(
    gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [AppTheme.goldBright, AppTheme.gold]),
    borderRadius: BorderRadius.circular(radius),
    boxShadow: [BoxShadow(color: AppTheme.gold.withOpacity(.20), blurRadius: 18, offset: const Offset(0, 7))],
  );
}
