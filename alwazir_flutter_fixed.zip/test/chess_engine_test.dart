import 'package:flutter_test/flutter_test.dart';
import '../lib/chess_engine.dart';

void main(){
  test('initial position has 20 legal moves',(){final s=ChessState.initial();expect(ChessEngine.allLegal(s,ColorSide.white),hasLength(20));});
  test('FEN round trip',(){const fen='rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';expect(ChessState.fromFen(fen).toFen(),fen);});
  test('castling is legal when path is clear',(){final s=ChessState.fromFen('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1');final moves=ChessEngine.legal(s,7,4);expect(moves.any((m)=>m.uci=='e1g1'),true);expect(moves.any((m)=>m.uci=='e1c1'),true);});
  test('en passant is generated and applied',(){final s=ChessState.fromFen('4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 2');final moves=ChessEngine.legal(s,3,4);final ep=moves.firstWhere((m)=>m.uci=='e5d6');final n=ChessEngine.apply(s,ep);expect(n.board[3][3],isNull);expect(n.board[2][3],'P');});
  test('promotion generates all four choices',(){final s=ChessState.fromFen('4k3/P7/8/8/8/8/8/4K3 w - - 0 1');final moves=ChessEngine.legal(s,1,0);expect(moves.map((m)=>m.uci).toSet(),containsAll(['a7a8q','a7a8r','a7a8b','a7a8n']));});
  test('fools mate is checkmate',(){var s=ChessState.initial();Move m(String u)=>ChessEngine.allLegal(s,s.turn).firstWhere((x)=>x.uci==u);for(final u in ['f2f3','e7e5','g2g4','d8h4'])s=ChessEngine.apply(s,m(u));final st=ChessEngine.status(s);expect(st.status,'checkmate');expect(st.winner,ColorSide.black);});
  test('stalemate is detected',(){final s=ChessState.fromFen('7k/5Q2/6K1/8/8/8/8/8 b - - 0 1');expect(ChessEngine.status(s).status,'stalemate');});
  test('insufficient material is detected',(){final s=ChessState.fromFen('8/8/8/8/8/8/6N1/4K2k w - - 0 1');expect(ChessEngine.status(s).status,'insufficient');});
}
